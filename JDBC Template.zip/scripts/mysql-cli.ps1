docker exec -it mysql mysql $args
