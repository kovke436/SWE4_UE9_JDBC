package swe4.jdbc.dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Collection;

public class PersonDaoJdbc implements PersonDao {
	private Connection connection;
	private String connectionString, userName, password;
	
	public PersonDaoJdbc(String connectionString, String userName, String password) {
		this.connectionString = connectionString;
		this.userName         = userName;
		this.password         = password;
	}
	
	private Connection getConnection() throws DataAccessException {
		if(connection == null)
			try { connection = DriverManager.getConnection(connectionString, userName, password); }
			catch(SQLException exc) { throw new DataAccessException("Can't establish connection to database. SQLException: " + exc.getMessage()); }
		return connection;		
	}

	@Override
	public void close() throws DataAccessException {
		if(connection != null) try {
			connection.close();
			connection = null;
		} catch(SQLException exc) { throw new DataAccessException("SQLException: " + exc.getMessage()); }
	}

	@Override
	public int getCount() throws DataAccessException {
		// TODO
		return 0;
	}

	@Override
	public Person getById(int id) throws DataAccessException {
		// TODO
		return null;
	}

	@Override
	public Collection<Person> getByLastName(String lastName) throws DataAccessException {
		// TODO
		return null;
	}

	@Override
	public Collection<Person> getAll() throws DataAccessException {
		// TODO
		return null;
	}

	@Override
	public void store(Person person) throws DataAccessException {
		// TODO
	}

	@Override
	public void delete(int id) throws DataAccessException {
		// TODO		
	}

	@Override
	public void update(Person person) throws DataAccessException {
		// TODO		
	}
}